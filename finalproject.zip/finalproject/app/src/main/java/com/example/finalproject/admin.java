package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class admin extends AppCompatActivity {
    ListView listView;


    String names[] = {"Sepertiga Malam", "Tak Puas", "Anak Nakalku", "Dunia Kini Minggu Pagi pun Merebak", "Menyerah","Sembahyang Rindu","Sepi","Aku Mencintaimu","Bintang Untuk Sahabat","Di Koridor Sekolah","Motivator Sejati","Penghianatan Sahabat","Menangislah Sobat","Puisi-Puisi Doa Untuk Sahabat"};
    String desc[] = {"Sepertiga Malam\n" +
            "Di sepertiga malam itu,\n" +
            "Rintik-rintik hujan kemudian membangunkan aku dari lelap\n" +
            "Mataku terbuka\n" +
            "Tiba-tiba, aku merasa rindu sekali bercerita kepada Tuhan\n" +
            "Tuhan, Lelahku hari ini menghasilkan tangis kejar\n" +
            "Aku ingin bangkit,\n" +
            "Namun realita yang tak sesuai kemudian harap Kembali lagi menjatuhkanku\n" +
            "Tuhan, Aku kemudian selalu ingin menutup hari dengan tawa\n" +
            "Namun selalu ada kecewa yang mendera-dera\n" +
            "Haruskah aku untuk berpura-pura bahagia?\n" +
            "Di sepertiga malam, aku kembali mengaduh Tuhanku Maha Mendengar\n" +
            "Aku kemudian akan terus berdoa hingga Tuhan memberiku Rasa Bahagia\n",
            "Tak Puas…\n" +
                    "Hutan telah mulai menguning\n" +
                    "Sungai telah beracun limbah\n" +
                    "Ikan-ikan mati tak bersisa\n" +
                    "Makhluk binasa dan tak ada lagi pangan\n" +
                    "Uang melimpah dan tak terhitung berapa jumlah\n" +
                    "Mataku silau pada harta namun tak tahu apa bunganya\n",
            "Kemana saja kau hingga kotor wajahmu\n"+
                    "Kesayanganku dengan wajah yang kotor\n" +
                    "Aku mencarimu hingga ikut kotor\n" +
                    "kemudian mencuci semua bajumu\n" +
                    "aku menemukan permen karet di sepatumu\n" +
                    "dan tahu itu permen karet\n" +
                    "aku juga kamu bermain di tempat sampah\n" +
                    "aduhh,, pusing rasanya,, melihat kamu\n" +
                    "namun aku tak sanggup tidur tanpa kamu\n" +
                    "anakku,\n" +
                    "dan kesayanganku\n",
            "Bagai daun kering yang berguguran\n" +
                    "Tak henti-hentinya ia berguguran\n" +
                    "Saat semuanya terlena dan berubah\n" +
                    "Sekelompok manusia kemudian berencana yang mengubah\n" +
                    "Yang salah kemudian menjadi seperti biasa\n" +
                    "Yang aneh kemudian menjadi seperti wajar\n" +
                    "Hati-hatilah sayang\n" +
                    "Itulah duniaku, kini.\n",
            "Di kala senja melebur dan mengelabu\n" +
                    "Di kala matahari kemudian sangat lelah dan tak mau lagi duduk berbincang\n" +
                    "Kelebatan malam kemudian tidak lagi memberikan ultimatum dan ketakutan\n" +
                    "Hingga jendela pun menjadi tertutup tak membuatku turut masuk\n" +
                    "Kursi yang ada di teras kemudian teramat nyaman jika kau disebelahnya\n" +
                    "Rasa sakit menjadi teramat berat hingga saat matahari tiba masih ingin ia terduduk\n" +
                    "Aku telah beranjak\n" +
                    "Mencoba mengeringkan luka serta berusaha merajut kembali\n" +
                    "Tidak ada kamu dan matahari\n" +
                    "Aku masih berlama di sana\n" +
                    "Berteriak di dalam kerinduan kepada jiwa-jiwa yang telah pergi","Aku kini harus menyerah\n",
            "Sudah kucoba bertahan namun tak kuasa\n" +
                    "Karenanya Aku harus menyerah\n" +
                    "Besar harapanku untuk dapat bertahan namun hati tak dapat juga menerima\n" +
                    "Aku ini harus menyerah\n" +
                    "Rasa sakit telah terlalu parah hingga membuat hatiku pecah dan bergelimang darah\n" +
                    "Dan perasaanku menjadi porak-poranda\n" +
                    "Aku menjadi harus menyerah\n" +
                    "Kan kututup setiap lembar kisah serta mimpi-mimpi indah hidup ini\n" +
                    "Cukup sudah sampai disini,\n" +
                    "aku menyerah.\n",
            "Bahkan ombak ini menolak membawa rinduku kepadamu\n" +
                    "Bersama angin kemudian disembahyangkan diri\n" +
                    "Mentakbirkan daun serta rumput\n" +
                    "Melambai-lambai jauh padamu\n" +
                    "Gelora doa serta dzikir ombak\n" +
                    "Mentasbihkan ia pasir-pasir\n" +
                    "Menghampar ia sepanjang waktu\n" +
                    "Kini baru kupahami\n" +
                    "Rindu bertahun ku wirid di angin-angin malam\n" +
                    "Belum sampai padamu\n" +
                    "Seperti juga ombak pulang balik ke tepian\n" +
                    "Hanya deru zikirku yang menjadi lantang\n" +
                    "Seperti pekik pungguk yang memanggil bulan\n" +
                    "Tangisku menjadi mengeris lengang\n" +
                    "Menunggu-nunggu kau datang\n" +
                    "Seperti kemudian menangkap bayang\n" +
                    "Di pancaran cahayaMu yang cerlang",
            "Tersebab, Tak mungkin kita bersama\n" +
                    "Maka aku selalu menuliskan syair-syair di hati\n" +
                    "Dimanakah kehidupan dunia dapat diatur sesuai mauku\n" +
                    "Lantas kamu dan aku menjadi kita\n" +
                    "Hanya dapat memanggil ingatan untuk kemudian mengusir kesunyian\n" +
                    "Tapi ia kemudian datang tak pernah sendirian\n" +
                    "Selalu ia beserta kerinduan\n" +
                    "Terbayang suatu hari tangan kita terkait\n" +
                    "Terlelap-lelap bersama dibawah saku langit\n" +
                    "Sepi ini kemudian selalu mengantarkanku padamu",
            "Aku mampu bernarasi dan bercerita\n" +
                    "Aku mampu berimaji dan mampu berpuisi\n" +
                    "Menuangkan segala kata-kata di hati\n" +
                    "Padamu aku sungguh mencintai\n" +
                    "Luasnya benua kemudian tak seluas harapanku\n" +
                    "Indahnya senja kemudian sama indahnya dengan puisiku\n" +
                    "Aku lumpuh jika aku jadi kehilangan\n" +
                    "Kehilangan segala urusan bait-bait\n" +
                    "juga kehilangan cinta sepertimu\n",
            "Malam sepi ini menarikku untuk keluar dari rumah.\n" +
                    "Kupandangi Langit malam yang bertaburkan Bintang\n" +
                    "tak terhitung jumlahnya\n" +
                    "Andai aku seorang bidadari\n" +
                    "Kuterbangkan aku dan sahabatku ke langit ketujuh\n" +
                    "Kuraih bintang-bintang terindah,\n" +
                    "dan kupersembahkan untuk ia sahabatku\n" +
                    "yang selalu menemaniku.",
            "Apa kabar Kau yang di sana?\n" +
                    "Tahukah kamu, bahwa Aku selalu tak percaya dengan semua ini\n" +
                    "Setiap pulang sekolah aku kemudian selalu di sini\n" +
                    "Karena di tempat ini, Di koridor sekolah kita selalu bersama,\n" +
                    "Bermain, dan tertawa\n" +
                    "Meskipun ragamu entah dimana\n" +
                    "Dan jiwamu telah melayang-melayang\n" +
                    "Tapi dalam hati serta pikiranku masih ada kau, sahabat",
            "Sang sahabat utusan Tuhan\n" +
                    "Ajakan serta nasihat yang engkau beri\n" +
                    "Jadikanlah sosok yang berarti\n" +
                    "Guna dewasaku di masa depan\n" +
                    "Motivator sejati\n" +
                    "Kau beri penataran serta ciptakan solusi\n" +
                    "dari perangkap kehidupan yang membelenggu pemikiran\n" +
                    "Semangat motivasi tak henti\n" +
                    "Dari pengalaman yang kau beri\n" +
                    "Ikhlas serta tulus arahanmu\n" +
                    "Tuk raih tujuan hidupku\n" +
                    "Motivator sejati…\n" +
                    "Jangan kau pergi\n" +
                    "Dari kehidupan ini\n" +
                    "Tinggalkan ku sendiri\n" +
                    "Urai muslihat berduri\n" +
                    "Dalam sepinya ide yang kumiliki.",
            "Kau hadir\n" +
                    "Dalam suka serta dukaku\n" +
                    "Di kala sedih kau ada\n" +
                    "ku suka kau juga ada\n" +
                    "Kau, sahabatku\n" +
                    "Dulu…\n" +
                    "Secercah tawamu yang indah kemudian selalu menggelitik jiwaku untuk tersenyum\n" +
                    "Tapi kini semua berubah\n" +
                    "Hitam tak jadi putih kembali\n" +
                    "Selama ini…\n" +
                    "Kutahu benar sifat-sifatmu\n" +
                    "Namun ku keliru bahkan, bahkan aku tahu sifat aslimu\n" +
                    "Telah dibuat akan mata ini, Rasanya tak akan dapat kubedakan\n" +
                    "dimana kebaikan asli dan mana yang palsu\n" +
                    "Kau tusuk aku dari belakang dan beberkan kejelekanku\n" +
                    "Sungguh tak ku sangka\n" +
                    "Kau balas persahabatan ini dengan itu\n" +
                    "Mungkin hanya seperti itu saja arti sahabat bagimu.",
            "Tak dapat ungkap dengan kata apapun\n" +
                    "Hal Ini memang sangat membosankan\n" +
                    "Hal Ini begitu melelahkan\n" +
                    "Bahkan, hal ini menjadi sangat menjengkelkan\n" +
                    "Tubuh seakan beku dalam bongkahan es\n" +
                    "Ia membeku tidak tahu kapan akan mencair\n" +
                    "Yaa… itu benar sobat\n" +
                    "Itu semua kemudian seperti sorot lampu panggung tanpa penonton\n" +
                    "Menerangi tubuhmu di dalam kegelapan\n" +
                    "Terdiam bisu tanpa senyum dan air mata\n" +
                    "Ini sungguh sangat menyedihkan..\n" +
                    "Namun.. ingatlah sobat..\n" +
                    "Kau tak sendiri, tak berdiri sendiri di kegelapan itu\n" +
                    "Teteskanlah air matamu jika hatimu menjadi terisak\n" +
                    "Berteriaklah sepuasmu jika hatimu memanas\n" +
                    "Karena itu kemudian akan membuatmu lebih baik\n",
            "Tuhan terimakasih ku katakan…\n" +
                    "Kau hadirkan ia menjadi sahabatku…\n" +
                    "Tuhan terimakasih….\n" +
                    "Kau hadirkan ia menjadi terangku…\n" +
                    "Sehingga tampak jelas kemana jalanku kemana aku ayunkan langkahku…\n" +
                    "Berikanlah dia sinar cahaya-Mu dan tambahkan cantiknya\n" +
                    "Berikanlah dia suaraMu dan tambahkan akal dan bijaknya\n" +
                    "Berikanlah dia kekayaan-Mu dan tambahkan rezekinya\n" +
                    "Berikanlah dia jalan-Mu dan bukakan jodohnya\n" +
                    "Berikanlah dia nafasMu dan panjangkan umurnya\n" +
                    "Dia yang semalam\n" +
                    "Tersenyum di dalam mimpiku.\n"};
    ArrayAdapter<String> arrayAdapter;
    ArrayAdapter<String> baseAdapter;
    List<ItemsModel> listItems = new ArrayList<>();

    Intent intent = getIntent();

    user.CustomAdaptor customAdaptor;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        getSupportActionBar().hide();

        listView = findViewById(R.id.listview);

        ImageView leftIcons = findViewById(R.id.left_icons);

        CustomAdapter customAdapter = new CustomAdapter(this, names, desc);
        listView.setAdapter(customAdapter);

        leftIcons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(admin.this, admin_profile.class);
                startActivity(intent);
            }
        });

    }

    public class CustomAdapter extends ArrayAdapter<String> {
        private String[] names;
        private String[] desc;

        public CustomAdapter(@NonNull Context context, String[] names, String[] desc) {
            super(context, R.layout.custom_list_item, names);
            this.names = names;
            this.desc = desc;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            View customView = layoutInflater.inflate(R.layout.custom_list_item, parent, false);

            String name = names[position];
            String description = desc[position];

            TextView nameTextView = customView.findViewById(R.id.nameTextView);
            TextView descTextView = customView.findViewById(R.id.descriptionTextView);

            nameTextView.setText(name);
            descTextView.setText(description);

            return customView;
        }
    }

}